Make sure the file.txt which store the information of peers is under same folder where class files are stored.
How to run: 
First compile the code using “java -Xlint *.java”
Then run “java Main listening_port name sending_port”
listening_port name sending_port should be got from the file.txt
E.g java Main 2001 Bob 3001
You can open a new terminal window and add more peers as long as the peers are from file.txt.